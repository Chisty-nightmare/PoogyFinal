#ifndef SCENE_H_INCLUDED
#define SCENE_H_INCLUDED
#include<stdio.h>
#include"iGraphics.h"
void drawSlide (){
	
	
}


#endif // SCENE_H_INCLUDED